<!DOCTYPE html>
<html>
  <head>
  <!--<link rel="stylesheet" type="text/css" href="style.css">-->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>SIS-Home Page</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="all,follow" />
    <!-- Bootstrap CSS-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css"
    />
    <!-- Font Awesome CSS-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/font-awesome/css/font-awesome.min.css"
    />
    <!-- Fontastic CSS-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/font.css"
    />
    <!-- Google fonts - Open Sans-->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700"
    />
    <!-- Swiper carousel-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/swiper/css/swiper.css"
    />
    <!-- Lity-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/lity/lity.css"
    />
    <!-- Bootstrap Select-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap-select/css/bootstrap-select.css"
    />
    <!-- Theme stylesheet-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css"
      id="theme-stylesheet"
    />
    <link id="new-stylesheet" rel="stylesheet" />
    <!-- Custom stylesheet - for your changes-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/custom.css"
    />
    <style>
      .login-container{
    margin-top: 5%;
    margin-bottom: 5%;
}
.login-logo{
    position: relative;
    margin-left: -41.5%;
}
.login-logo img{
    position: absolute;
    width: 20%;
    margin-top: 19%;
    background: #282726;
    border-radius: 4.5rem;
    padding: 5%;
}
.login-form-1{
    padding: 9%;
    background:#282726;
    box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
}
.login-form-1 h3{
    text-align: center;
    margin-bottom:12%;
    color:#fff;
}
.login-form-2{
    padding: 9%;
    background: #f05837;
    box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
}
.login-form-2 h3{
    text-align: center;
    margin-bottom:12%;
    color: #fff;
}
.btnSubmit{
    font-weight: 600;
    width: 50%;
    color: #282726;
    background-color: #fff;
    border: none;
    border-radius: 1.5rem;
    padding:2%;
}
.btnForgetPwd{
    color: #fff;
    font-weight: 600;
    text-decoration: none;
}
.btnForgetPwd:hover{
    text-decoration:none;
    color:#fff;
}
    </style>
  </head>
  <body>
    <!-- header-->
    <header class="header">
      <!-- top bar-->
      <div class="top-bar d-none d-md-block">
        <div class="container">
          <div class="row">
            
                <div class="logo">
                    <h3>INQUISITIVE</h3><br><small>ASK YOUR QUESTION</small>
                  </div>
            
          </div>
        </div>
      </div>
    </header>
<div class="container login-container" style="width: 56%;">
  <div class="row">
      <div class="col-md-6 login-form-1">
          <h3>Student</h3>
          
              <div class="form-group">
                  <input type="text" class="form-control" placeholder="Your Email *" value="" />
              </div>
              <div class="form-group">
                  <input type="password" class="form-control" placeholder="Your Password *" value="" />
              </div>
              <div class="form-group">
                  <input type="submit" class="btnSubmit" value="Login" />
              </div>
              <div class="form-group">
                  <input type="submit" class="btnSubmit" value="Sign Up"/>
              </div>
          
      </div>
      <div class="col-md-6 login-form-2" style="background-color: #6a4e77;">
          <div class="login-logo">
              <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
          </div>
          <h3>Teacher</h3>
              <div class="form-group">
                  <input type="text" class="form-control" placeholder="Your Email *" value="" />
              </div>
              <div class="form-group">
                  <input type="password" class="form-control" placeholder="Your Password *" value="" />
              </div>
              <div class="form-group">
                  <input type="submit" class="btnSubmit" value="Login" />
              </div>
          </form>
      </div>
  </div>
</div>


    <footer class="footer pb-0">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="logo">
              <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
            </div>
            </div>
        </div>
      </div>
    </footer>
  </body>
</html>
