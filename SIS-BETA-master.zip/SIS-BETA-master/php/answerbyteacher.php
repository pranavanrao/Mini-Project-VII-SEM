<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        Template -SIS
    </title>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />
    <style>
        .titlename {
            padding-top: 20px;
            font-size: 250%;
            text-align: center;
            font-family: cursive, sans-serif;
        }

        .qipanel {
            margin: auto;
            width: 60%;
            border: 2px solid #a8abac;

        }

        .qicontanier {
            margin: auto;
            width: 100%;
            border-bottom: 1px solid #959899;
            padding: 10px;
        }

        .question {
            align-self: center;
        }

        .meta {
            float: right;
            margin-left: 0px;
        }


        .qtimestamp {
            float: right;

        }

        .author {
            float: right;
            padding-left: 40px;
            padding-bottom: 0px;
            margin-bottom: 0px;
            align-content: bottom;
        }

        .post {
            background-color: green;
            height: 30px;
            width: 50px;
            border: 0cm;
        }
    </style>
</head>

<body>
    <?php session_start(); ?>
    <!-- header-->

    <header class="header">
        <!-- top bar-->
        <div class="top-bar d-none d-md-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">

                    </div>
                    <div class="col-md-6 text-right">
                        <ul class="list-inline mb-0">
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- navbar-->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a href="home.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
                <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
                    <span></span><span></span><span></span>
                </button>
                <div id="navbarSupportedContent" class="collapse navbar-collapse">
                    <div class="navbar-nav ml-auto">
                        <div class="nav-item">
                            <a href="home.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
                        </div>
                        <div class="nav-item">
                            <a href="aboutusteacher.php" class="nav-link">About US </a>
                        </div>
                        <div class="nav-item">
                            <a href="logout.php" class="nav-link">LOGOUT </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>


    <p class="titlename"><strong>Answer Book</strong></p>

    <?php
    //session already started after the body
    $host = "127.0.0.1";
    $user = "root";
    $pass = "";
    $dbname = "sis";
    $c = 0;
    $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
    if (!$conn) {
        echo ("Server not connected" . mysqli_error($conn));
    } else {
        ?>
        <div class="qipanel">

            <?php
                $qid = $_GET["qid"];
                $querysql="SELECT * FROM question,student where question.studentid=student.sid and question.qid=$qid;";
                $sql = mysqli_query($conn, $querysql);
               // echo $querysql;
                if (!$sql) {
                    echo "Error" . mysqli_error($sql);
                } else {
                    if (mysqli_num_rows($sql) >= 0) {
                        while ($row = mysqli_fetch_assoc($sql)) {

                            ?>

                        <div class="qicontanier">
                            <div class="question">
                                <label><strong><?php echo $row['qid'] . " . " . $row['query']  ?></strong></label>
                            </div>
                            <div class="meta">
                                <span class="qtimestamp"><strong>at <?php echo substr($row['qtimestamp'], 0, 16) ?></strong></span>
                                <span class="author"><i>Asked by </i> <?php echo $row['sfirst_name'] . $row['slast_name'] ?> , </span>
                                <br><br>
                            </div>
                            <br>



                            <?php

                        }
                    }
                }
                // $querysql="SELECT * FROM answer,teacher where question.studentid=student.sid and question.qid=$qid;";
                // $sql = mysqli_query($conn, $querysql);
                // echo $querysql;
                // if (!$sql) {
                //     echo "Error" . mysqli_error($sql);
                // } else {
                //     if (mysqli_num_rows($sql) >= 0) {
                //         while ($row = mysqli_fetch_assoc($sql)) {

                            ?>
<!-- 
                        <div class="qicontanier">
                            <div class="question">
                                <label><strong><?php echo $row['qid'] . " . " . $row['query']  ?></strong></label>
                            </div>
                            <div class="meta">
                                <span class="qtimestamp"><strong>at <?php echo substr($row['qtimestamp'], 0, 16) ?></strong></span>
                                <span class="author"><i>Asked by </i> <?php echo $row['sfirst_name'] . $row['slast_name'] ?> , </span>
                                <br><br>
                            </div>
                            <br>

 -->

                            <?php

                //         }
                //     }
                // }


echo $row['answerid'];
                                            if ($row['answerid'] == NULL) {

                                                $aid = $row['answerid'];
                                                $nextqid = 0;

                                                $querysql = "SELECT * FROM answer,teacher where answer.teacherid=teacher.tid and answer.forqid='$qid' ORDER BY answer.aid DESC";
                                                
                                                //$sql2 = mysqli_query($conn, "SELECT * FROM answer,teacher,commenttable WHERE answer.teacherid=teacher.tid and answer.commentid=commenttable.cid and answer.aid='$aid';");
                                                $sql2 = mysqli_query($conn, $querysql);
                                                if (!$sql2) {
                                                    echo "Error" . mysqli_error($sql);
                                                } else {
                                                    if (mysqli_num_rows($sql2) >= 0) {
                                                        while ($row2 = mysqli_fetch_assoc($sql2)) {
                                                            ?>
                                            <label for="individualAnswerView">Answer ID : <?php echo $row2['aid'];
                                                                                                                            $nextindex = $row2['indexaid'];  ?></label>
                                            <div class="card">
                                                <div class="card-body">
                                                    <?php echo $row2['astring']; ?>
                                                </div>
                                                <div class="meta">
                                                    <span class="qtimestamp"><strong>at <?php echo substr($row2['atimestamp'], 0, 16) ?></strong></span>
                                                    <span class="author"><i>Answerd by </i> <?php echo $row2['first_name'] . $row2['Last_name'] ?> , </span>
                                                </div>

                                                <!-- <div class="card-footer bg-transparent border-success">Footer</div> -->

                                            </div>

                            <?php


                                                        }
                                                    }
                                                }
                                            }



                                            ?>



                            <form action="safehouse_answerinsert.php" method="GET">
                                <div class="form-group">
                                    <label for="newanswer1">Type your answer:</label>
                                    <textarea class="form-control" name="qid" hidden id="qid" rows="1"><?php echo $_GET['qid'] ?></textarea>
                                    <textarea class="form-control" name="newanswer" required id="newanswer" rows="3"></textarea>
                                </div>
                                <center>
                                <button type="submit" name="submit" class="btn btn-success">Submit</button></center>
                            </form>
                            <BR>
                            <a class="btn btn-warning" href="qboard.php" role="button">GO BACK</a>
                
                        </div>



        </div>



<?php
    //         }
    //     }
    // }
    ?>

<?php
    //echo ("Status: Server is connected");
    // echo $nextindex+1;
}


//INSERT INTO `answer` (`aid`, `astring`, `teacherid`, `commentid`, `nextaid`, `atimestamp`) VALUES ('5', 'gvbnm,', '1', NULL, NULL, '2019-11-10 11:26:26.429397')
?>



<footer class="footer pb-0">
    <div class="container">
        <div class="row">

            <div class="col-lg-3">
                <h4 class="text-thin">Navigation</h4>
                <div class="d-flex flex-wrap">
                    <ul class="navigation list-unstyled">
                        <li><a href="home.php">Home </a></li>
                        <li><a href="aboutus.php">About Us</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="logo">
                    <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
                </div>
                <ul class="social list-inline">
                    <li class="list-inline-item">
                        <a href="#" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                    </li>
                </ul>
            </div>

        </div>
    </div>
</footer>


</body>

</html>