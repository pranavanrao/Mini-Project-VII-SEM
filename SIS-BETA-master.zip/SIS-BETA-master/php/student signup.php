<!DOCTYPE html>
<html>
  <head>
  <!--<link rel="stylesheet" type="text/css" href="style.css">-->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>SIS-Home Page</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="all,follow" />
    <!-- Bootstrap CSS-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css"
    />
    <!-- Font Awesome CSS-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/font-awesome/css/font-awesome.min.css"
    />
    <!-- Fontastic CSS-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/font.css"
    />
    <!-- Google fonts - Open Sans-->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700"
    />
    <!-- Swiper carousel-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/swiper/css/swiper.css"
    />
    <!-- Lity-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/lity/lity.css"
    />
    <!-- Bootstrap Select-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap-select/css/bootstrap-select.css"
    />
    <!-- Theme stylesheet-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css"
      id="theme-stylesheet"
    />
    <link id="new-stylesheet" rel="stylesheet" />
    <!-- Custom stylesheet - for your changes-->
    <link
      rel="stylesheet"
      href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/custom.css"
    />
    </head>
    <body>
        <centre>
    <div class="container" id="wrap" style="align-items: center;">
	  <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form action="r" method="post" accept-charset="utf-8" class="form" role="form">   
                    <h2>Student Sign Up</h2>
                    <div class="row">
                        <div class="col-xs-6 col-md-6">
                            <input type="text" name="firstname" value="" class="form-control input-lg" placeholder="First Name"  />                        </div>
                        <div class="col-xs-6 col-md-6">
                            <input type="text" name="lastname" value="" class="form-control input-lg" placeholder="Last Name"  />                        </div>
                    </div>
                    <input type="text" name="email" value="" class="form-control input-lg" placeholder="Your Email"  /><input type="password" name="password" value="" class="form-control input-lg" placeholder="Password"  /><input type="password" name="confirm_password" value="" class="form-control input-lg" placeholder="Confirm Password"  />
                            <input type="text" name="collage" value="" class="form-control input-lg" placeholder="Collage"  />
                           <label>Semester</label> <select name="sem" class="form-control input-lg" >
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>                         
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                </select>
                                <label>Branch</label> <select name="branch" class="form-control input-lg">
                                        <option>CSE</option>
                                        <option>ISE</option>
                                        <option>ECE</option>
                                        <option>EEE</option>
                                        <option>ME</option>                         
                                        <option>IT</option>
                                        </select>
                                        <label>Section</label> <select name="sec" class="form-control input-lg">
                                                <option>A</option>
                                                <option>B</option>
                                                <option>C</option>
                                                </select>
                                    
                            
                    
                           <label>DOB</label><input type="date" name="date" value="" class="form-control input-lg" placeholder="DOB"/><br>
                                 
                    
                     <label>Gender : </label>                    <label class="radio-inline">
                        <input type="radio" name="gender" value="M" id=male />                        Male
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="gender" value="F" id=female />                        Female
                    </label>
                    <br />
                    <button class="form-control input-lg" type="submit" style="background-color: #6a4e77; font-style:white" >
                        Create my account</button></div>
            </form>          
          </div>
</div>            
</div>
</div>
</centre>
  </body>
</html>