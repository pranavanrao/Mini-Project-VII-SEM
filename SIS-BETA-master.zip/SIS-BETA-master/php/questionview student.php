<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    QUESTION -SIS
  </title>
  <!-- Bootstrap CSS-->
  <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
  <!-- Theme stylesheet-->
  <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />

  <style>
    .titlename {

      font-size: 200%;
    }

    .qipanel {
      margin: auto;
      width: 60%;
      border: 2px solid #a8abac;
      overflow: auto;

    }

    .qicontanier {
      margin: auto;
      width: 100%;
      border-bottom: 1px solid #959899;
      padding: 10px;
      overflow: auto;
    }

    .question {
      align-self: center;
    }

    .meta {
      float: right;
      margin-left: 0px;
      position: relative;
    }


    .qtimestamp {
      float: right;

    }

    .author {
      float: right;
      padding-left: 40px;
      padding-bottom: 0px;
      margin-bottom: 0px;
      align-content: bottom;
    }
  </style>

</head>

<body>
  <?php session_start(); ?>
  <!-- header-->
  <header class="header">
    <!-- top bar-->
    <div class="top-bar d-none d-md-block">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
          </div>
          <div class="col-md-6 text-right">
          <ul class="list-inline mb-0">
              <?php echo $_SESSION['suser'];  ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- navbar-->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a href="studentHome.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
          <span></span><span></span><span></span>
        </button>
        <div id="navbarSupportedContent" class="collapse navbar-collapse">
          <div class="navbar-nav ml-auto">
            <div class="nav-item">
              <a href="studentHome.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
            </div>
            <div class="nav-item">
              <a href="aboutusstudent.php" class="nav-link">About US </a>
            </div>
            <div class="nav-item">
              <a href="logout.php" class="nav-link">LOGOUT </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <?php
  //session already started after the body
  $host = "127.0.0.1";
  $user = "root";
  $pass = "";
  $dbname = "sis";
  $c = 0;
  $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
  if (!$conn) {
    echo ("Server not connected" . mysqli_error($conn));
  } else {
    ?>


    <div class="qipanel">
      <p class="titlename">
        <h1><span class="badge badge-secondary">Question View</span></h1>
      </p>

      <?php
        $qid = $_GET['qid'];
        $tid = 1;
        $SHOWQUESTION = 1;
        $sqlquery = "Select * from answer,question WHERE answer.forqid='$qid' and answer.forqid=question.qid";
        $sql = mysqli_query($conn, $sqlquery);
        if (!$sql) {
          echo "Error" . mysqli_error($sql);
        } else {
          if (mysqli_num_rows($sql) >= 0) {


            while ($row = mysqli_fetch_assoc($sql)) {
              if ($SHOWQUESTION) {
                ?>
              <div class="qicontanier" style="overflow:auto">
                <div class="question">
                  <?php echo $row['qid'] . " . " . $row['query']  ?>
                  </a> <br>
                </div>
                <div class="meta">
                  <span class="qtimestamp"><strong>at <?php echo substr($row['qtimestamp'], 0, 16) ?></strong></span>
                  <span class="author"><i>Asked by </i> Rohith,</span>
                </div>
              </div>
              <h3><b>Your Answer </b></h3>
            <?php
                      $SHOWQUESTION = 0;
                    } ?>

            <div class="container">
              <div class="form-group">
                <br>

                <textarea id="answer" rows="5" style="width: 100%;"><?php echo $row['astring'] ?></textarea>
              </div>


            </div>
      <?php
            }
          } else {
            echo "No answers Found";
          }
        }
        ?>

      <br>
      <div>
        </div>
        
      <br>
    </div>

    <div style="width: 100px;
	height: 100px;

	
	
	top:0;
	bottom: 0;
	left: 0;
	right: 0;
  	
	margin: auto;">
    <a class="btn btn-success" style=" padding-left: 10%; padding-right:10%; float:right" href="questionhistory.php" role="button">GO BACK</a>
     
    </div>
    
  <?php
    // echo ("Status: Server is connected");
  }
  ?>

  <br><br>
  <footer class="footer pb-0">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-3">
          <h4 class="text-thin">Navigation</h4>
          <div class="d-flex flex-wrap">
            <ul class="navigation list-unstyled">
              <li><a href="studentHome.php">Home </a></li>
              <li><a href="aboutusstudent.php">About Us</a></li>
            </ul>
          </div>
        </div>
        
        <div style="float:right" class="col-lg-4">
          <div class="logo">
            <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
          </div>
        </div>

      </div>
    </div>
  </footer>
</body>

</html>