<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <!--<link rel="stylesheet" type="text/css" href="style.css">-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        SIS
    </title>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />

    <style>
        .login-container {
            margin-top: 5%;
            margin-bottom: 5%;
        }

        .login-logo {
            position: relative;
            margin-left: -41.5%;
        }

        .login-logo img {
            position: absolute;
            width: 20%;
            margin-top: 19%;
            background: #282726;
            border-radius: 4.5rem;
            padding: 5%;
        }

        .login-form-1 {
            padding: 9%;
            background: #282726;
            box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
        }

        .login-form-1 h3 {
            text-align: center;
            margin-bottom: 12%;
            color: #fff;
        }

        .login-form-2 {
            padding: 9%;
            background: #f05837;
            box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
        }

        .login-form-2 h3 {
            text-align: center;
            margin-bottom: 12%;
            color: #fff;
        }

        .btnSubmit {
            font-weight: 600;
            width: 50%;
            color: #282726;
            background-color: #fff;
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
        }

        .btnForgetPwd {
            color: #fff;
            font-weight: 600;
            text-decoration: none;
        }

        .btnForgetPwd:hover {
            text-decoration: none;
            color: #fff;
        }
    </style>
</head>

<body>
    <?php 

    ?>
    <?php
// print_r($_SESSION);
?>
    <!-- header-->
    <header class="header">
        <!-- top bar-->
        <div class="top-bar d-none d-md-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6 text-right">
                        <ul class="list-inline mb-0">
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- navbar-->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a href="loginpage.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
                <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
                    <span></span><span></span><span></span>
                </button>
                <div id="navbarSupportedContent" class="collapse navbar-collapse">
                    <div class="navbar-nav ml-auto">
                        <div class="nav-item">
                            <a href="loginpage.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>



    <div class="container login-container" style="width: 56%;">
        <div class="row">
            <div class="col-md-6 login-form-1">
                <h3>Student</h3>
                <form action="authoriser.php">
                    <input type="text" name="role" value="student" hidden />
                    <div class="form-group">
                        <input type="email"  required name="sname" class="form-control" placeholder="Your Email" value="" />
                    </div>
                    <div class="form-group">
                        <input type="password" required name="spass" class="form-control" placeholder="Your Password" value="" />
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btnSubmit" value="Login/Sign UP" />
                    </div>
                </form>
            </div>
            <?php

            ?>
            <div class="col-md-6 login-form-2" style="background-color: #6a4e77;">
                <div class="login-logo">
                    <img src="loginrocket.png" alt="" />
                </div>
                <h3>Teacher</h3>
                <form action="authoriser.php">
                    <input type="text" name="role" value="teacher" hidden />
                    <div class="form-group">
                        <input type="email" required name="sname" class="form-control" placeholder="Your Email" value="" />
                    </div>
                    <div class="form-group">
                        <input type="password" required name="spass" class="form-control" placeholder="Your Password" value="" />
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btnSubmit" value="Login" />
                    </div>
                </form>
            </div>
            <div class="col-md-12 login-form-1" style="background-color: grey;">
                
                <h3>Admin</h3>
                <form action="authoriser.php">
                    <input type="text" name="role" value="admin" hidden />
                    <div class="form-group">
                        <input type="email" required name="sname" class="form-control" placeholder="Your Email" value="" />
                    </div>
                    <div class="form-group">
                        <input type="password" required name="spass" class="form-control" placeholder="Your Password" value="" />
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btnSubmit" value="Login" />
                    </div>
                </form>
            </div>
        </div>
    </div>


    <footer class="footer pb-0">
        <div class="container">
            <div class="row">

                <div style="float:right" class="col-lg-4">
                    <div class="logo">
                        <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
                        <br>
                    </div>
                </div>

            </div>
        </div>
    </footer>
</body>

</html>