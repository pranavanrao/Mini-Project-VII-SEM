<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        Profile -SIS
    </title>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />


</head>

<body>
    <?php session_start();
      $tid= $_SESSION["tid"];                    
       ?>
    <!-- header-->
    <header class="header">
        <!-- top bar-->
        <div class="top-bar d-none d-md-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        
                    </div>
                    <div class="col-md-6 text-right">
                        <ul class="list-inline mb-0">
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- navbar-->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a href="home.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
                <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
                    <span></span><span></span><span></span>
                </button>
                <div id="navbarSupportedContent" class="collapse navbar-collapse">
                    <div class="navbar-nav ml-auto">
                        <div class="nav-item">
                            <a href="home.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
                        </div>
                        <div class="nav-item">
                            <a href="aboutusteacher.php" class="nav-link">About US </a>
                        </div>
                        <div class="nav-item">
                            <a href="logout.php" class="nav-link">LOGOUT </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>


    <?php
    //session already started after the body
    $host = "127.0.0.1";
    $user = "root";
    $pass = "";
    $dbname = "sis";

    $c = 0;
    $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
    if (!$conn) {
        echo ("Server not connected" . mysqli_error($conn));
    } else {

        $sql = mysqli_query($conn, "SELECT * FROM teacher where tid='$tid'");
        if (!$sql) {
            echo "Error" . mysqli_error($sql);
        } else {
            if (mysqli_num_rows($sql) >= 0) {
                while ($row = mysqli_fetch_assoc($sql)) {
                    ?>

                    <div class="container">
                        <br>
                        <br>
                        <div class="row" id="main">
                            <div class="col-md-4 well" id="leftPanel">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div>
                                            <!-- <img src="https://cdn5.vectorstock.com/i/1000x1000/99/94/default-avatar-placeholder-profile-icon-male-vector-23889994.jpg" alt="Texto Alternativo" class="img-circle img-thumbnail"> -->
                                            <img src="<?php echo $row['image'] ?>" alt="Profile Image" class="img-circle img-thumbnail">
                                            <h2><?php echo $row['first_name'] ?></h2>
                                            <p><?php echo $row['designation'] ?></p>
                                            <p><?php echo $row['branch'] ?></p>
                                            <p><?php echo $row['college'] ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                            $noofquestionresult = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) FROM `answer` WHERE teacherid='$tid'"));

                                            ?>
                            <div class="col-md-8 well" id="rightPanel">
                                <div class="row">
                                    <div class="col-md-12">
                                        <form action="home.php">
                                            <h2>Edit your profile.</h2>
                                            <span class="icon-star _537e4"></span>
                                            <hr class="colorgraph">
                                            <label><b>ID No:</b> <?php echo $row['tid'] ?></label><br>
                                            <label><b>Questions answered:</b> <?php echo $noofquestionresult['COUNT(*)'] ?></label><br>
                                            <label><b>Rating Scored:</b> <?php echo $row['rating'] ?></label>
                                            <hr class="colorgraph">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" disabled name="first_name" id="first_name" value="<?php echo $row['first_name'] ?>" class="form-control input-lg" placeholder="First Name" tabindex="1">
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" disabled name="last_name" id="last_name" value="<?php echo $row['Last_name'] ?>" class="form-control input-lg" placeholder="Last Name" tabindex="2">
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" disabled id="email" value="<?php echo $row['email'] ?>" class="form-control input-lg" placeholder="Email Address" tabindex="4">
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" disabled name="gender" id="gender" class="form-control input-lg" value="<?php echo $row['gender'] ?>" tabindex="1">
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="date" disabled name="doj" value="<?php echo $row['doj'] ?>" id="doj" class="form-control input-lg" placeholder="doj" tabindex="2">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" disabled name="branch" id="branch" readonly class="form-control input-lg" value="<?php echo $row['branch'] ?>" placeholder="Branch" tabindex="1">
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" disabled name="col_name" id="col_name" readonly class="form-control input-lg" value="<?php echo $row['college'] ?>" placeholder="College Name" tabindex="2">
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="colorgraph">
                                            <strong><label>Teaching Experience</label></strong>
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" readonly name="experience" id="experience" class="form-control input-lg" value="<?php echo $row['experience'] . " years" ?>" placeholder="Experience" tabindex="1">
                                                    </div>
                                                </div>

                                            </div>
                                            <strong><label>Fields of Interest/Subjects Taught</label></strong>
                                            <textarea rows=4 disabled name="foi" id="foi" class="form-control input-lg" placeholder="Fields of Interest" tabindex="4"><?php echo $row['specialization'] ?></textarea>

                                            <hr class="colorgraph">

                                            <div class="row">
                                                <div class="col-xs-12 col-md-6"></div>
                                                <a class="btn btn-success" href="home.php" role="button">Go back to Home page</a>
                                                <!-- <div class="col-xs-12 col-md-6"><input type="submit" name="submit" value="Submit" class="btn btn-success btn-block btn-lg"></a></div> -->
                                            </div>
                                        </form>
                                        <br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        <?php
                    }
                }
            }
            ?>








        <br>


    <?php
        // echo ("Status: Server is connected");
    }
    ?>

<footer class="footer pb-0">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-3">
                    <h4 class="text-thin">Navigation</h4>
                    <div class="d-flex flex-wrap">
                        <ul class="navigation list-unstyled">
                            <li><a href="home.php">Home </a></li>
                            <li><a href="aboutus.php">About Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="logo">
                        <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
                    </div>
                    <ul class="social list-inline">
                        <li class="list-inline-item">
                            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                </div>
                
            </div>
        </div>
    </footer>

</body>

</html>