<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        ABOUT US -SIS
    </title>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />
</head>

<body>
    <!-- header-->
    <header class="header">
    <!-- top bar-->
    <div class="top-bar d-none d-md-block">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
          </div>
          <div class="col-md-6 text-right">
            <ul class="list-inline mb-0">
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- navbar-->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a href="studentHome.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
          <span></span><span></span><span></span>
        </button>
        <div id="navbarSupportedContent" class="collapse navbar-collapse">
          <div class="navbar-nav ml-auto">
            <div class="nav-item">
              <a href="studentHome.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
            </div>
            <div class="nav-item">
              <a href="aboutusstudent.php" class="nav-link">About US </a>
            </div>
            <div class="nav-item">
              <a href="logout.php" class="nav-link">LOGOUT </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  </header>

    <table>
        <tr>
            <td>
    <div class="flex-coloum" >
    <div class="indiv" style="background-color:black";>
    <div class="card-body">
        <h3 style="color:white;">Who are we?</h3>
                    </div>
</div>
    <div class="indiv" style="background-color:#6a4e77";>
    <div class="card-body">
    <a href="#" style="color:white"><h4>Sukesh Naga</h4></a><br>
    <a href="mailto:nagasukesh@gmail.com" style="color:black">nagasukesh@gmail.com</a><br>
    <a href="#" style="color:black">7013334071</a></b>
                    </div>
</div>
<div class="indiv" style="background-color:#6a4e77";>
    <div class="card-body">
    <a href="#" style="color:white"><h4>Rohith V R</h4></a><br>
    <a href="mailto:rohithvr3@gmail.com" style="color:black">rohithvr3@gmail.com</a><br>
    <a href="#" style="color:black">7022202242</a></b>
                    </div>
</div>
<div class="indiv" style="background-color:#6a4e77";>
    <div class="card-body">
    <a href="#" style="color:white"><h4>Pranav N Rao</h4></a><br>
    <a href="mailto:pranavanrao@gmail.com" style="color:black">pranavanrao@gmail.com</a><br>
    <a href="#" style="color:black">7013334071</a></b>
                    </div>
</div>
</div>
</td>
<td valign="top">
<div class="card-body">
<h3>What we do</h3>
</div>
<div class="card-body" style="width:90%; font-size:18px">
    <i>INQUISITIVE is the online community that helps students for clarification of doubths in any subject.
        It is developing online community that is restricted to each institute.INQUISITIVE fills the gap between lecturers and students by providing
        platform to gain the knowledge and clarification of doubts.It is end to end web service helping students in different ways 
        by interacting with the lecturers.The community boots the perfomance of student in its own ways.<br><br><br>
            <h1 style="font-size:24">               <center>           INQUISITIVE</center>                             </h1>
</i>
</div>
</td>
</tr>
</table>

      
        

<footer class="footer pb-0">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-3">
          <h4 class="text-thin">Navigation</h4>
          <div class="d-flex flex-wrap">
            <ul class="navigation list-unstyled">
              <li><a href="studentHome.php">Home </a></li>
              <li><a href="aboutusstudent.php">About Us</a></li>
            </ul>
          </div>
        </div>
        
        <div style="float:right" class="col-lg-4">
          <div class="logo">
            <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
          </div>
        </div>

      </div>
    </div>
  </footer>
</body>

</html>