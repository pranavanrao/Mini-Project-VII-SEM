<?php
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "sis";
if (isset($_GET['submit'])) {
    date_default_timezone_set('Asia/Kolkata');
    $timestamp= date('Y-m-d H:i:s');  
    $timestamp=$timestamp.'.405405';
    $bid=$_GET['bid'];
    $sid=$_GET['sid'];
    $tid=$_GET['tid'];
    $newans=$_GET['banswer'];
    

echo "hahahah";
$conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
if (!$conn) {
    echo ("Server not connected" . mysqli_error($conn));
} else {
    $querystring="INSERT INTO `broadcastAnswer` (`baid`, `tid`, `sid`, `banswer`, `batimestamp`) VALUES ('$bid', '$tid', '$sid', '$newans','2019-11-26 08:21:21') ON duplicate KEY UPDATE banswer='$newans',batimestamp='$timestamp'";
    echo $querystring;
    $sql = mysqli_query($conn, $querystring);
    if (!$sql) {
        echo "Error2" . mysqli_error($sql);
    } else {
       
            echo "rowinsert line2 ";

            header("Location: studentHome.php"); /* Redirect browser */
            exit();
            
        
    }
    
}
} else {
echo "loll";
}
