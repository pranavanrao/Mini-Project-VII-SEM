
<?php
session_start();

    $tid=time();


    $firstname = $_GET['firstname'];
    $lastname = $_GET['lastname'];
    $email = $_GET['email'];
    $password = $_GET['password'];
    $designation=$_GET['designation'];
    $collage = $_GET['collage'];
    $specalisation = $_GET['specalisation'];
    $branch = $_GET['branch'];
    $exper = $_GET['exper'];
    $imageurl = $_GET['imageurl'];
    $doj = $_GET['date'];
    $gender = $_GET['gender'];
    $role = "teacher";
    date_default_timezone_set('Asia/Kolkata');
    $timestamp= date('Y-m-d H:i:s');  
    $timestamp=$timestamp.'.405405';
    echo $timestamp ;   
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "sis";
$c = 0;
$conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");

$sqlquery = "INSERT INTO `teacher` (`tid`, `first_name`, `Last_name`, `designation`, `email`, `gender`, `doj`, `branch`, `college`, `specialization`, `experience`, `rating`, `image`, `ttimestamp`) VALUES ('$tid', '$firstname ', '$lastname', '$designation', '$email', '$gender', '$doj', '$branch', '$collage', '$specalisation', '$exper', '3', '$imageurl', '$timestamp')";
//echo $sqlquery;

$sql = mysqli_query($conn, $sqlquery);
if (!$sql) {
    echo "Error" . mysqli_error($sql);
} else {
    
        $sqlquery = "INSERT INTO `login` (`username`, `idno`,`password`, `role`) VALUES ('$email',$tid, '$password', '$role')";
        //echo $sqlquery;
        $sql = mysqli_query($conn, $sqlquery);
        echo "You will be redirected to login page in 4 seconds";
header('Refresh: 4; URL=loginpage.php');


        exit();
    }

?>
