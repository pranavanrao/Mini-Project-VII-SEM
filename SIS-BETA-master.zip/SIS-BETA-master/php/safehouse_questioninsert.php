<?php
session_start();
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "sis";
if (isset($_GET['submit'])) {
    date_default_timezone_set('Asia/Kolkata');
    $timestamp= date('Y-m-d H:i:s');  
    $timestamp=$timestamp.'.405405';
    echo $timestamp ;
    $qid=time();
    $newqtext=$_GET['newquery'];
    $assignprof=$_GET['assignProf'];
    $assigntag=$_GET['assignTag'];
    $studentid=$_SESSION['sid'];
    echo $studentid;


echo "hahahah";
$conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
if (!$conn) {
    echo ("Server not connected" . mysqli_error($conn));
} else {
    $querystring="INSERT INTO `question` (`qid`, `query`, `tagid`, `fortid`, `answerid`, `votes`, `studentid`, `qtimestamp`) VALUES ('$qid', '$newqtext', '$assigntag', '$assignprof', NULL, '0', '$studentid', '$timestamp')";
    echo $querystring;
    $sql = mysqli_query($conn, $querystring);
    if (!$sql) {
        echo "Error2" . mysqli_error($sql);
    } else {
       
            echo "rowinsert line2 ";

            header("Location: studentHome.php"); /* Redirect browser */
            exit();
            
        
    }
    
}
} else {
echo "loll";
}
