<html>

<head>
    <title>
        Authoriser
    </title>
</head>

<body>
    <?php
    session_start();
    $username = $_GET['sname'];
    $password = $_GET['spass'];
    $role = $_GET['role'];
    $host = "127.0.0.1";
    $user = "root";
    $pass = "";
    $dbname = "sis";
    $c = 0;
    $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
    $sqlquery = "Select * from login where username='$username' and password='$password' and role='$role'";
    //echo $sqlquery;
    $sql = mysqli_query($conn, $sqlquery);
    if (!$sql) {
        echo "Error" . mysqli_error($sql);
    } else {
        if (mysqli_num_rows($sql) > 0) {
            $row = mysqli_fetch_assoc($sql);
            if ($role == "teacher") {
                header("Location: home.php");
                $_SESSION["role"] = "teacher";
                $_SESSION["tuser"] = "$username";
                $_SESSION["tid"] = $row['idno'];
            } else if ($role == "student") {
                header("Location: studentHome.php");
                $_SESSION["role"] = "student";
                $_SESSION["suser"] = "$username";
                $_SESSION["sid"] = $row['idno'];
            } else if ($role == "admin") {
                $_SESSION["role"] = "admin";
                $_SESSION["auser"] = "$username";
                $_SESSION["tid"] = $row['idno'];
                header("Location:adminpage.php");
            }
            exit();
        } else {

            if ($role == "student") {
                header("Location: signupstudent.php");
                exit();
            } else {

                echo "<script type='text/javascript'> 
                        alert('Wrong Password..!');
                        </script>";
                echo "You will be redirected to Login Page.. ....";

                header('Refresh: 1; URL=loginpage.php');
                exit();
            }
        }
    }
    ?> </body>

</html>