
<?php
session_start();
$firstname = $_GET['firstname'];
$lastname = $_GET['lastname'];
$email = $_GET['email'];
$password = $_GET['password'];
$collage = $_GET['collage'];
$sem = $_GET['sem'];
$branch = $_GET['branch'];
$sec = $_GET['sec'];
$usn = $_GET['usn'];
$dob = $_GET['date'];
$gender = $_GET['gender'];
$role = $_GET['role'];
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "sis";
$c = 0;
$conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
$sqlquery = "INSERT INTO `student` (`sid`, `sfirst_name`, `slast_name`, `gender`, `dob`, `sem`, `USN`, `branch`, `section`, `college`, `email`, `stimestamp`) VALUES ('$usn', '$firstname', ' $lastname', '$gender', '$dob', '$sem', '$usn', '$branch', '$sec', '$collage', '$email', '2019-11-20 09:23:23.405405')";
echo $sqlquery;
$sql = mysqli_query($conn, $sqlquery);
if (!$sql) {
    echo "Error" . mysqli_error($sql);
} else {

        $sqlquery = "INSERT INTO `login` (`username`, `idno`, `password`, `role`) VALUES ('$email', '$usn','$password', '$role')";
        echo $sqlquery;
        $sql = mysqli_query($conn, $sqlquery);
        echo "redirection ahead";
       header("Location: loginpage.php");
        exit();
    }

?>
