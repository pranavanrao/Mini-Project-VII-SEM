<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        Template -SIS
    </title>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />


</head>

<body>
    <!-- header-->
    <header class="header">
        <!-- top bar-->
        <div class="top-bar d-none d-md-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6 text-right">
                        <ul class="list-inline mb-0">
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- navbar-->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a href="studentHome.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
                <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
                    <span></span><span></span><span></span>
                </button>
                <div id="navbarSupportedContent" class="collapse navbar-collapse">
                    <div class="navbar-nav ml-auto">
                        <div class="nav-item">
                            <a href="logout.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <centre>
        <div class="container" id="wrap" style="align-items: center;">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <form action="registersignup.php" method="GET" accept-charset="utf-8" class="form" role="form">
                        <h2>Student Sign Up</h2>
                        <div class="row">
                            <div class="col-xs-6 col-md-6">
                                <input type="text" name="firstname" value="" class="form-control input-lg" placeholder="First Name" /> </div>
                            <div class="col-xs-6 col-md-6">
                                <input type="text" name="lastname" value="" class="form-control input-lg" placeholder="Last Name" /> </div>
                        </div>
                        <input type="text" name="role" value="student" hidden />
                        <input type="text" name="email" value="" class="form-control input-lg" placeholder="Your Email" /><input type="password" name="password" value="" class="form-control input-lg" placeholder="Password" />
                        <input type="text" name="collage" value="" class="form-control input-lg" placeholder="Collage" />
                        <label>Semester</label> <select name="sem" class="form-control input-lg">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                            <option>7</option>
                            <option>8</option>
                        </select>
                        <label>Branch</label> <select name="branch" class="form-control input-lg">
                            <option>CSE</option>
                            <option>ISE</option>
                            <option>ECE</option>
                            <option>EEE</option>
                            <option>ME</option>
                            <option>IT</option>
                        </select>
                        <label>Section</label> <select name="sec" class="form-control input-lg">
                            <option>A</option>
                            <option>B</option>
                            <option>C</option>
                        </select>
                        <label>USN : </label>
                        <input type="text" name="usn" value="" class="form-control input-lg" placeholder="Your USN" />



                        <label>DOB</label><input type="date" name="date" value="" class="form-control input-lg" placeholder="DOB" /><br>


                        <label>Gender : </label> <label class="radio-inline">
                            <input type="radio" name="gender" value="M" id=male /> Male
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="gender" value="F" id=female /> Female
                        </label>
                        <br />
                        <button class="form-control input-lg" type="submit" style="background-color: #6a4e77; font-style:white">
                            Create my account</button>
                </div>
                </form>
            </div>
        </div>
        </div>
        </div>
    </centre>
    <!-- THIS IS THE BODY OF THE PAGE -->

    <footer class="footer pb-0">
        <div class="container">
            <div class="row">

                <div style="float:right" class="col-lg-4">
                    <div class="logo">
                        <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
                        <br>
                    </div>
                </div>

            </div>
        </div>
    </footer>
</body>

</html>