<?php
session_start();
$host = "127.0.0.1";
  $user = "root";
  $pass = "";
  $dbname = "sis";
  $c = 0;
  $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
  if (!$conn) {
    echo ("Server not connected" . mysqli_error($conn));
  } else {
      $sql = mysqli_query($conn, "SELECT * FROM question,student where question.studentid=student.sid;");
      if (!$sql) {
          echo "Error" . mysqli_error($sql);
      } else {
          if (mysqli_num_rows($sql) >= 0) {
              while ($row = mysqli_fetch_assoc($sql)) {
              }
          }
      }
  }
?>