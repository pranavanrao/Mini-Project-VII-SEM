<?php
session_start();
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "sis";
if (isset($_GET['submit'])) {
    $qid = $_GET['qid'];
    date_default_timezone_set('Asia/Kolkata');
    $timestamp= date('Y-m-d H:i:s');  
    $timestamp=$timestamp.'.405405';
    echo $timestamp ;


    echo "hahahah";
    $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
    if (!$conn) {
        echo ("Server not connected" . mysqli_error($conn));
    } else {
        $sql = mysqli_query($conn, "SELECT MAX(indexaid) FROM answer where forqid='$qid'");
        if (!$sql) {
            echo "Error2" . mysqli_error($sql);
        } else {
            echo "rowinsert line1 ";
            $rowinsert = mysqli_fetch_assoc($sql);
            $nextindex = $rowinsert['MAX(indexaid)'] + 1;
            $newaid = time();
            echo "new aid is " . $newaid;
            $newans = $_GET['newanswer'];
            $tid = $_SESSION['tid'];
            echo "<br>";
            $executequery = "INSERT INTO `answer` (`aid`, `forqid`, `astring`, `teacherid`, `commentid`, `indexaid`, `atimestamp`) VALUES ('$newaid', '$qid', '$newans', '$tid', NULL, '$nextindex', '$timestamp')";
            echo $executequery;
            $sql = mysqli_query($conn, $executequery);

            if (!$sql) {
                echo "Error2" . mysqli_error($sql);
            } else {
                echo "Insert Successful";
                
            }
            echo "rowinsert line2 ";
            echo "<script type='text/javascript'>
            console.log('IN safehouse');
                        alert('Insert Successful..!');
                        </script>";
                       header( "refresh:0;url=home.php" );/* Redirect browser */
            // exit();
        }
    }
} else {
    echo "loll";
}
