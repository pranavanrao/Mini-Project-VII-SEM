<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>
        BroadCast -SIS
    </title>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/vendor/bootstrap/css/bootstrap.min.css" />
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="https://d19m59y37dris4.cloudfront.net/university/1-1-1/css/style.default.css" id="theme-stylesheet" />

    <style>
        .titlename {

            font-size: 200%;
        }

        .qipanel {
            margin: auto;
            width: 60%;
            border: 2px solid #a8abac;

        }

        .qicontanier {
            margin: auto;
            width: 100%;
            border-bottom: 1px solid #959899;
            padding: 10px;
        }

        .question {
            align-self: center;
        }

        .author {
            margin-left: 80%;
        }

        .qtimestamp {
            margin-left: 80%;
        }

        .dropbtn {
            background-color: #6a4e77;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
        }

        /* The container <div> - needed to position the dropdown content */
        .dropdown1,
        .dropdown2,
        .dropdown3 {
            position: relative;
            display: inline-block;
        }

        /* Dropdown Content (Hidden by Default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown menu on hover */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Change the background color of the dropdown button when the dropdown content is shown */
        .dropdown:hover .dropbtn {
            background-color: #6a4e77;
        }
    </style>

</head>

<body>
    <?php session_start(); ?>
    <!-- header-->
    <header class="header">
        <!-- top bar-->
        <div class="top-bar d-none d-md-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">

                    </div>
                    <div class="col-md-6 text-right">
                        <ul class="list-inline mb-0">
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- navbar-->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a href="home.php" class="navbar-brand"><strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small></a>
                <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right mt-0">
                    <span></span><span></span><span></span>
                </button>
                <div id="navbarSupportedContent" class="collapse navbar-collapse">
                    <div class="navbar-nav ml-auto">
                        <div class="nav-item">
                            <a href="home.php" class="nav-link active">Home <span class="sr-only">(current)</span></a>
                        </div>
                        <div class="nav-item">
                            <a href="aboutusteacher.php" class="nav-link">About US </a>
                        </div>
                        <div class="nav-item">
                            <a href="logout.php" class="nav-link">LOGOUT </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <br>


    <?php

    //session already started after the body
    $host = "127.0.0.1";
    $user = "root";
    $pass = "";
    $dbname = "sis";
    $c = 0;
    $conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
    if (!$conn) {
        echo ("Server not connected" . mysqli_error($conn));
    } else {
        ?>

        <?php
            $tid = '1';
            $sql = mysqli_query($conn, "SELECT * FROM student;");
            if (!$sql) {
                echo "Error" . mysqli_error($sql);
            } else {
                if (mysqli_num_rows($sql) >= 0) {

                    while ($row = mysqli_fetch_assoc($sql)) {

                        ?>

        <?php
                    }
                }
            }
            ?>
        <center> <a class="btn btn-warning" href="previousbroadcast.php" role="button">Broadcast history</a></center>
        <br>
        <div class="qipanel">
            <p class="titlename"><strong>BroadCast</strong></p>
            <div class="qicontanier">
                <div class="question">
                    <form method="GET" action="safehouse_broadcast.php">
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Enter Assignment</label>
                            <textarea class="form-control" id="assignQuestion" name="assignQuestion" rows="5" placeholder="Assign the Work ."></textarea>
                        </div>


                        <?php

                            $sql = mysqli_query($conn, "SELECT DISTINCT sem FROM student");
                            if (!$sql) {
                                echo "Error" . mysqli_error($sql);
                            } else {
                                ?>
                            <div class="form-group">
                                <label for="exampleFormControlSelect1">Select Semester</label>
                                <select class="form-control" name="assignSem" id="assignSem">
                                    <?php
                                            if (mysqli_num_rows($sql) >= 0) {
                                                while ($row = mysqli_fetch_assoc($sql)) {
                                                    ?>



                                            <option><?php echo $row['sem'] ?></option>


                            </div>
                    <?php
                                }
                            }
                            ?> </select><?php
                                            }
                                            ?>
                <?php
                    $tid = '1';
                    $sql = mysqli_query($conn, "SELECT DISTINCT branch FROM student;");
                    if (!$sql) {
                        echo "Error" . mysqli_error($sql);
                    } else {
                        if (mysqli_num_rows($sql) >= 0) {
                            ?>
                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Select Branch</label>
                            <select class="form-control" name="assignBranch" id="assignBranch">

                                <?php

                                            while ($row = mysqli_fetch_assoc($sql)) {

                                                ?>

                                    <option> <?php echo $row['branch'] ?></option>

                            <?php
                                        }
                                    } ?>

                            </select>
                        </div><?php
                                    }
                                    ?>

                    <?php

                        $tid = $_SESSION["tid"];
                        $sql = mysqli_query($conn, "SELECT DISTINCT section FROM student");
                        if (!$sql) {
                            echo "Error" . mysqli_error($sql);
                        } else {
                            if (mysqli_num_rows($sql) >= 0) {
                                ?>
                            <div class="form-group">
                                <label for="exampleFormControlSelect3">Select Section</label>
                                <select class="form-control" name="assignSection" id="assignSection">
                                    <?php
                                                while ($row = mysqli_fetch_assoc($sql)) {
                                                    ?>
                                        <option><?php echo $row['section'] ?></option>
                                    <?php
                                                }
                                                ?>
                                </select>
                            </div>
                    <?php
                            }
                        }
                        ?>
                    <button type="submit" name="submit" class="btn btn-primary">Send Assignment</button>
                    </form>
                </div>
            </div>

        </div>
        <!-- <div>
      <a class="btn btn-success" style=" padding-left: 10%; padding-right:10%;" href="home.php" role="button">GO to HOME PAGE</a>
    </div> -->
        <br>

    <?php
        // echo ("Status: Server is connected");
    }
    ?>
    </div>
    <br>
    <footer class="footer pb-0">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <h4 class="text-thin">Navigation</h4>
                    <div class="d-flex flex-wrap">
                        <ul class="navigation list-unstyled">
                            <li><a href="home.php">Home </a></li>
                            <li><a href="aboutus.php">About Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="logo">
                        <strong>INQUISITIVE</strong><small>ASK YOUR QUESTION</small>
                    </div>
                    <ul class="social list-inline">
                        <li class="list-inline-item">
                            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </footer>
</body>

</html>