<?php
session_start();
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "sis";
if (isset($_GET['submit'])) {
    $bid=time();
    $newassignQuestion=$_GET['assignQuestion'];
    $assignSem=$_GET['assignSem'];
    $assignBranch=$_GET['assignBranch'];
    $assignSection=$_GET['assignSection'];
    $tid= $_SESSION["tid"];      
    date_default_timezone_set('Asia/Kolkata');
    $timestamp= date('Y-m-d H:i:s');  
    $timestamp=$timestamp.'.405405';
    echo $timestamp ;              


echo "hahahah";
$conn = mysqli_Connect("$host", "$user", "$pass", "$dbname");
if (!$conn) {
    echo ("Server not connected" . mysqli_error($conn));
} else {
    $querystring="INSERT INTO `broadcast` (`bid`, `bstring`, `teacherid`, `sem`, `branch`, `section`, `btimestamp`) VALUES ('$bid', '$newassignQuestion', '$tid', '$assignSem', '$assignBranch', '$assignSection', '$timestamp')";
    echo "<br>".$querystring;
    $sql = mysqli_query($conn, $querystring);
    if (!$sql) {
        echo "Error2" . mysqli_error($sql);
    } else {

       
            echo "rowinsert line2 ";
           header("Location: home.php"); /* Redirect browser */
  exit();
    }
    
}
} else {
echo "loll";
}
