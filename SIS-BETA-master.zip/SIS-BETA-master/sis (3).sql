-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 06, 2019 at 01:33 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sis`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `aid` varchar(10) NOT NULL,
  `forqid` varchar(10) NOT NULL,
  `astring` varchar(2000) NOT NULL,
  `teacherid` varchar(10) DEFAULT NULL,
  `commentid` varchar(10) DEFAULT NULL,
  `indexaid` varchar(10) DEFAULT NULL,
  `atimestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='information about answer';

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`aid`, `forqid`, `astring`, `teacherid`, `commentid`, `indexaid`, `atimestamp`) VALUES
('1575362813', '1575362772', 'Php is used to design server side web pages', '1575302319', NULL, '1', '2019-12-03 14:16:53.405405'),
('1575362841', '1575362772', 'Php is used to design server side web pages and is the main scripting language ', '1575302319', NULL, '2', '2019-12-03 14:17:21.405405');

-- --------------------------------------------------------

--
-- Table structure for table `broadcast`
--

CREATE TABLE `broadcast` (
  `bid` varchar(10) NOT NULL,
  `bstring` varchar(300) NOT NULL,
  `teacherid` varchar(10) NOT NULL,
  `sem` int(1) NOT NULL,
  `branch` varchar(3) NOT NULL,
  `section` varchar(2) NOT NULL,
  `btimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Information of broadcast table';

--
-- Dumping data for table `broadcast`
--

INSERT INTO `broadcast` (`bid`, `bstring`, `teacherid`, `sem`, `branch`, `section`, `btimestamp`) VALUES
('1575362890', 'What does isset() do B?', '1575302319', 7, 'CSE', 'B', '2019-12-03 14:18:10'),
('1575362907', 'What does isset() do? a?', '1575302319', 7, 'CSE', 'A', '2019-12-03 14:18:27');

-- --------------------------------------------------------

--
-- Table structure for table `broadcastAnswer`
--

CREATE TABLE `broadcastAnswer` (
  `baid` varchar(10) NOT NULL,
  `tid` varchar(10) NOT NULL,
  `sid` varchar(10) NOT NULL,
  `banswer` varchar(500) NOT NULL,
  `batimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Broadcast Answers';

--
-- Dumping data for table `broadcastAnswer`
--

INSERT INTO `broadcastAnswer` (`baid`, `tid`, `sid`, `banswer`, `batimestamp`) VALUES
('1575362890', '1575302319', '1bg16cs067', 'checks  for presence of variable B', '2019-11-26 08:21:21'),
('1575362907', '1575302319', '1BG16CS117', 'checks  for presence of variable A', '2019-11-26 08:21:21');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `idno` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `idno`, `password`, `role`) VALUES
('aa@gmail.com', '1BG16CS110', 'aa', 'student'),
('admin@gmail.com', '100', '123', 'admin'),
('nagasukesh@gmail.com', '1bg16cs067', '123', 'student'),
('prarthanatv@bnmit.in', '1575302319', 'p123', 'teacher'),
('ranjanaschakrasali@bnmit.in', '1575356642', 'r123', 'teacher'),
('rohithvr3@gmail.com', '1BG16CS117', '123', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `qid` varchar(10) NOT NULL,
  `query` varchar(1000) NOT NULL,
  `tagid` varchar(10) NOT NULL,
  `fortid` varchar(10) NOT NULL,
  `answerid` varchar(10) DEFAULT NULL,
  `votes` int(5) NOT NULL,
  `studentid` varchar(10) NOT NULL,
  `qtimestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='information about question';

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`qid`, `query`, `tagid`, `fortid`, `answerid`, `votes`, `studentid`, `qtimestamp`) VALUES
('1575362749', 'What are the applications of machine learning ?', '3', '1575356642', NULL, 0, '1BG16CS117', '2019-12-03 14:15:49.405405'),
('1575362772', 'Application of Php ?', '1', '1575302319', NULL, 0, '1BG16CS117', '2019-12-03 14:16:12.405405'),
('1575363098', 'B section question here 1', '1', '1575302319', NULL, 0, '1bg16cs067', '2019-12-03 14:21:38.405405');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` varchar(10) NOT NULL,
  `sfirst_name` varchar(50) NOT NULL,
  `slast_name` varchar(20) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `dob` date NOT NULL,
  `sem` int(1) NOT NULL,
  `USN` varchar(10) NOT NULL,
  `branch` varchar(3) NOT NULL,
  `section` varchar(2) NOT NULL,
  `college` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `stimestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='information about student';

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `sfirst_name`, `slast_name`, `gender`, `dob`, `sem`, `USN`, `branch`, `section`, `college`, `email`, `stimestamp`) VALUES
('1bg16cs067', 'SUKESH', ' N', 'M', '2009-06-16', 7, '1bg16cs067', 'CSE', 'B', 'BNMIT', 'nagasukesh@gmail.com', '2019-12-03 08:54:18.439799'),
('1BG16CS110', 'Name', ' as', 'M', '1212-11-23', 2, '1BG16CS110', 'ECE', 'C', 'BNMIT', 'aa@gmail.com', '2019-11-20 09:23:23.405405'),
('1BG16CS117', 'ROHITH', ' V R', 'M', '1998-12-25', 7, '1BG16CS117', 'CSE', 'A', 'BNMIT', 'rohithvr3@gmail.com', '2019-11-20 09:23:23.405405');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE `tag` (
  `tagid` varchar(10) NOT NULL,
  `tagname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`tagid`, `tagname`) VALUES
('1', 'Web Technology '),
('2', 'DBMS'),
('3', 'MACHINE LEARNING');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `tid` varchar(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `Last_name` varchar(20) DEFAULT NULL,
  `designation` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `doj` date NOT NULL,
  `branch` varchar(3) NOT NULL,
  `college` varchar(30) NOT NULL,
  `specialization` text NOT NULL,
  `experience` int(2) NOT NULL,
  `rating` float NOT NULL,
  `image` varchar(350) NOT NULL,
  `ttimestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='information about teacher';

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `first_name`, `Last_name`, `designation`, `email`, `gender`, `doj`, `branch`, `college`, `specialization`, `experience`, `rating`, `image`, `ttimestamp`) VALUES
('1575302319', 'Prarthana ', 'T.V', 'Associate Professor ', 'prarthanatv@bnmit.in', 'F', '2013-07-22', 'CSE', 'BNMIT', 'Computer Vision, Video Processing', 6, 3, 'https://www.bnmit.org/wp-content/uploads/2019/05/PTV.jpg', '2019-12-02 21:28:39.405405'),
('1575356642', 'Ranjana  ', 'S Chakrasali', 'Assistant Professor ', 'ranjanaschakrasali@bnmit.in', 'F', '2013-02-01', 'CSE', 'BNMIT', 'Computer Science and Engineering', 13, 3, 'https://www.bnmit.org/wp-content/uploads/2019/05/RS.jpg', '2019-12-03 12:34:02.405405');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `teacherid` (`teacherid`);

--
-- Indexes for table `broadcast`
--
ALTER TABLE `broadcast`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `broadcastAnswer`
--
ALTER TABLE `broadcastAnswer`
  ADD PRIMARY KEY (`baid`,`tid`,`sid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`qid`),
  ADD KEY `answerid` (`answerid`),
  ADD KEY `studentid` (`studentid`),
  ADD KEY `tagid` (`tagid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`tagid`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`tid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`teacherid`) REFERENCES `teacher` (`tid`) ON DELETE CASCADE;

--
-- Constraints for table `broadcastAnswer`
--
ALTER TABLE `broadcastAnswer`
  ADD CONSTRAINT `broadcastAnswer_ibfk_1` FOREIGN KEY (`baid`) REFERENCES `broadcast` (`bid`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_2` FOREIGN KEY (`answerid`) REFERENCES `answer` (`aid`) ON DELETE CASCADE,
  ADD CONSTRAINT `question_ibfk_3` FOREIGN KEY (`studentid`) REFERENCES `student` (`sid`) ON DELETE CASCADE,
  ADD CONSTRAINT `question_ibfk_4` FOREIGN KEY (`tagid`) REFERENCES `tag` (`tagid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
